package com.example.hongstone;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Bt1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bt1);


    }
}
