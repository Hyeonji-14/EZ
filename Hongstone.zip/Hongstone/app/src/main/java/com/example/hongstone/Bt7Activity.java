package com.example.hongstone;

import androidx.appcompat.app.AppCompatActivity;

public class Bt7Activity extends AppCompatActivity {
}
